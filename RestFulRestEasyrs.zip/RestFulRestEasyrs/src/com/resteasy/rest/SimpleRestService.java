package com.resteasy.rest;


import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.FormParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import DAO.ManagerDAO;

@Path("/")
public class SimpleRestService {

	public ManagerDAO managerdao =new ManagerDAO();
	
	@GET
	@Path("communication/{host}")
    @Produces(MediaType.TEXT_PLAIN)
	public String getSomething(@PathParam("host") String host ,
			 @DefaultValue("1") @QueryParam("version") int version) {
	
		String response = null;
        try{			
            switch(version){
	            case 1:
	                try 
	                { 	               	
	                    Process p=Runtime.getRuntime().exec ("cmd /c ping "+host);  
	                    InputStream is = p.getInputStream(); 
	                    BufferedReader br = new BufferedReader (new InputStreamReader (is)); 
	                    String aux = br.readLine();
	                    response=aux;
	                    while (aux!=null) {
	                        System.out.println (aux);  
	                        aux = br.readLine();
	                        response+=aux;
	                        
	                    	} 
	                    
	                }catch (Exception e){
	                		e.printStackTrace();	                		
	                	} 
                    break;
                default: throw new Exception("Unsupported version: " + version);
            }
        }
        catch(Exception e){
        	response = e.getMessage().toString();
        }
        return response;	
	}

	@POST
	@Path("/login")
    @Produces(MediaType.TEXT_PLAIN)
	public String postSomething(@FormParam("user") String user ,@FormParam("password") String password , 
			@DefaultValue("1") @FormParam("version") int version, 
			@Context HttpServletRequest requestContext,@Context SecurityContext context,
			@HeaderParam("user-agent") String userAgent) {

		
		String response = null;

        try{			
            switch(version){
	            case 1:
	            	String ipAddress = requestContext.getRemoteAddr();
	            	managerdao.record(ipAddress,userAgent);
	            	
	                FileInputStream file = new FileInputStream(new File("C:/usuarios.xml"));
					
	    			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
	    			
	    			DocumentBuilder builder =  builderFactory.newDocumentBuilder();
	    			
	    			Document xmlDocument = builder.parse(file);

	    			XPath xPath =  XPathFactory.newInstance().newXPath();
	    			
	    			
	    			String expression = "/USUARIOS/USUARIO[UserName='"+user+"'] and /USUARIOS/USUARIO[Password='"+password+"']";
	    			
	    			String email = xPath.compile(expression).evaluate(xmlDocument);
	    			if(email.equals("true")){
	    				response="true";
	    			}else{
	    				response="false";
	    			}
                    break;            
                default: throw new Exception("Unsupported version: " + version);
            }
        }
        catch(Exception e){
        	response = e.getMessage().toString();
        }
        return response;	
	}

}
