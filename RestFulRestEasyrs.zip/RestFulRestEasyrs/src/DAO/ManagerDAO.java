package DAO;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ManagerDAO {

	public static EntityManagerFactory emf;
	public static EntityManager em;
	
	public ManagerDAO(){
		if(emf==null){
			emf=Persistence.createEntityManagerFactory("RestFulRestEasyrs");
		}
		if(em==null){
			em=emf.createEntityManager();
		}
	}
	
	
	public void record(String ip , String navegador){
		javax.persistence.Query q;
		em.getTransaction().begin(); 
		q=em.createQuery("select max(l.id) from Log l");
		int id=(int)q.getSingleResult()+1;
		em.createNativeQuery("insert into Log (id ,ip,navegador) values"
				+ " ("+id+",'"+ip+"','"+navegador+"')").executeUpdate();
		em.getTransaction().commit();
	}
}
