package com.rest.restlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.restlet.data.Form;
import org.restlet.representation.Representation;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import DAO.ManagerDAO;

public class SimpleRestService extends ServerResource {

	private static final Logger logger = Logger.getLogger(SimpleRestService.class);
	public ManagerDAO managerdao =new ManagerDAO();
	@Get
	@Path("/communication/{host}")
	@Produces(MediaType.TEXT_PLAIN)
	public String getSomething() {
		
		String host = (String)getRequest().getAttributes().get("host");
		
		if (logger.isDebugEnabled()) {
			logger.debug("Start getSomething");
			logger.debug("data: '" + host + "'");
		}

		String response = null;
        try 
        { 
        	
            Process p=Runtime.getRuntime().exec ("cmd /c ping "+host);  
            InputStream is = p.getInputStream(); 
            BufferedReader br = new BufferedReader (new InputStreamReader (is)); 
            String aux = br.readLine();
            response=aux;
            while (aux!=null) {
                System.out.println (aux);  
                aux = br.readLine();
                response+=aux;
                
            	} 
            
        }catch (Exception e){
        		e.printStackTrace();	                		
        	} 

		return response;
	}

	@Post
	@Path("/login")
	public String postSomething(Representation entity) throws ParserConfigurationException,
	SAXException, IOException, XPathExpressionException {

		
		Form form = new Form(entity);
		String user= form.getValues("user");
		String password= form.getValues("password");
		

		if (logger.isDebugEnabled()) {
			logger.debug("Start postSomething");
			logger.debug("data: '" + user + "'");
			logger.debug("data: '" + password + "'");
		}
		
		String ipAddress = "0.0.0.1";
    	managerdao.record(ipAddress,"MOZILLA");
		String response = null;
		
		FileInputStream file = new FileInputStream(new File("C:/usuarios.xml"));
		
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		
		DocumentBuilder builder =  builderFactory.newDocumentBuilder();
		
		Document xmlDocument = builder.parse(file);

		XPath xPath =  XPathFactory.newInstance().newXPath();
		
		
		String expression = "/USUARIOS/USUARIO[UserName='"+user+"'] "
				+ "and /USUARIOS/USUARIO[Password='"+password+"']";
		
		String email = xPath.compile(expression).evaluate(xmlDocument);
		if(email.equals("true")){
			response="true";
		}else{
			response="false";
		}

		return response;
	}

}
