package com.rest.cxf;

import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.lifecycle.SingletonResourceProvider;

public class ServiceRest {

	public static void main(String[] args) {
		 JAXRSServerFactoryBean sf = new JAXRSServerFactoryBean();
	        sf.setResourceClasses(SericeRESTAplication.class);
	        sf.setResourceProvider(SericeRESTAplication.class, 
	            new SingletonResourceProvider(new SericeRESTAplication()));
	        sf.setAddress("http://52.42.23.86:8080/RestfulCXF/cxf/");
	        Server server = sf.create();
	        sf.setStart(true);
	        
	        // destroy the server
	        // uncomment when you want to close/destroy it
	        // server.destroy();
	}
}
